#include<iostream>
using namespace std;
int main()
{
	//#pragma pack(1)
	char *p;
	int *i;
	float *f;
	cout<<sizeof(p);
	cout<<sizeof(i);
	cout<<sizeof(f)<<endl;
	return 0;
}