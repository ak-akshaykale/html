show databases
create database vinodtest; 
use vinodtest;
show tables;
create table stud(rollno int(10),name char(30));
select * from stud;
insert into stud values(101,"Vinod");