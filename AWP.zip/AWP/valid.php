<from method="GET">
	<input type="text" name="uname">
	<input type="submit" value="SUBMIT">
</from>
<?php
	$allowuser=array("akshay","vilas","sagar","deepak");
	//$curid="akshay";
	$isvalid=false;
	foreach($allowuser as $au)
	{
		if($_GET["uname"]==$au)
		{
			$isvalid=true;
		}
	}
	if(isvalid)
	{
		echo "Valid User ".$curid;
	}
?>