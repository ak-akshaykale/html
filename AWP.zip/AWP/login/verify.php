<?php
//echo "Hello ".$_GET["uid"];
$con=new mysqli("localhost","root","","ak");
$sq=$con->prepare("select * from newuser where user=?"); //where user=?
$sq->bind_param("s",$_GET["uid"]);
$sq->execute();
$rs=$sq->get_result();
//$row=$rs->fetch_assoc();
//echo "FETCH:".$row["user"];
if($rs->num_rows==0)
{
   echo "ua";
}
else
{
     echo "ur";
}
//echo "Hello ".$_GET["uid"];
?>