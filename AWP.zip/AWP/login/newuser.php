<?php
//echo "Hello ".$_GET["uid"];
 $con=new mysqli("localhost","root","","ak");
 $sq=$con->prepare("insert into newuser values(?,?)");
 $sq->bind_param("ss",$_GET["uid"],$_GET["pass"]);
 $res=$sq->execute();
 if($res==1)
 echo " User successfully Register";
 else
 echo " User Not Register";
?>