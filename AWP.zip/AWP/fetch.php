<?php
    $useid= $_REQUEST["userid"];
    echo "HI ".$userid;
?>