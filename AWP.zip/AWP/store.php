<?php
	$con=new mysqli("localhost:3307","root","","ak");
	//$sq=$con->prepare("select name from info");
	$sq=$con->prepare("insert into info values(?,?,?)");
	$sq->bind_param("sis",$_GET["name"],
	$_GET["age"],
	$_GET["addr"]);
	$sq->execute();
	//$rs=$sq->get_result();
	//$row=$rs->fetch_assoc();
	//echo $row["name"];
	echo "The information is now on Server";
?>