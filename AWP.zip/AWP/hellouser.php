<?php
	$name="AKSHAY";
	echo "WELCOME ".$name;
?>