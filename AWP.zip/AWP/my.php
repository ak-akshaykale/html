<?php
	echo "THIS IS COLOR";
?>