function change()
{
    
    console.table(document.getElementById("p"))
}
