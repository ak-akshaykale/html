<?php
	if($_GET)
	{
		print_r($_GET);
	}
?>
<form action="store.php" method="GET">
		NAME: <input type="text" name="name"> <br>
		Age: <input type="text" name="age"> <br>
		Address: <input type="text" name="addr"> <br>
		<!--Favorite subject: <input type="text"> <br>
		Movie: <input type="text"> <br>
		Singer: <input type="text"> <br>-->
		<input type="Submit" value="Submit"> <br>
</form>